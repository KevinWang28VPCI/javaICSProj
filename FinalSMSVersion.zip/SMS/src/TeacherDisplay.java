import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Add column stating if person is student or teacher, display teachers first then students
 * @author Kevin Wang, Piali Roy
 */
public class TeacherDisplay extends JFrame {
	// variables of class
	private JTable table;
	private String account;
	private static String col[] = { "Name", "Specialty", "Phone Number", "Address" }; // column headers
	private Object data[][] = {}; // no data for now
	private DefaultTableModel model;
	private Classroom classroom;
	private ArrayList<String> names;
	private ArrayList<String> specialty;
	private ArrayList<String> phone;
	private ArrayList<String> address;

	private ArrayList<Teacher> teachers;
	private static final long serialVersionUID = 1;

	/**
	 * Displays the teachers of the account 
	 * @param title
	 * @param account
	 */
	public TeacherDisplay(String title, String account) {
		super(title);
		this.account = account;
		
		model = new DefaultTableModel(data, col); // table with size data and column
		table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		JScrollPane scrollPane = new JScrollPane(table); // make scrollable
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		classroom = new Classroom(account); // gets the specefic classroom for the account
		System.out.println(classroom.getStudents());

		// directly get information from bufferedWriter reading from files dont have to
		// put in arrayList
		names = new ArrayList<String>();
		specialty = new ArrayList<String>();
		phone = new ArrayList<String>();
		address = new ArrayList<String>();
		teachers = new ArrayList<Teacher>();
		
		teachers = classroom.getTeachers();
		
		for (int b = 0; b < classroom.getTeachers().size(); b++)
		{
			names.add(teachers.get(b).getName());
			specialty.add(teachers.get(b).getSpecialty());
			phone.add(teachers.get(b).getPhoneNumber());
			address.add(teachers.get(b).getAddress());

		}

		// add rows to the JTable according to the amount of students there are
		for (int i = 0; i < names.size(); i++) {
			// Append a row
			model.addRow(new Object[] {  names.get(i), specialty.get(i), phone.get(i), address.get(i) }); // add info to rows
			// put this inside the loop for bufferedReader to easily create new columns
		}

		table.setRowHeight(25); // each row is 25 pix
		table.setEnabled(false); // not editable

		add(scrollPane); // add table to JFrame
	}
}