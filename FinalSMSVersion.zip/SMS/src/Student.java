import java.util.*;

/**
 * This class is the base for the students in a classroom
 * This takes care of the students name, id, grades etc.
 * @author Kevin Wang
 *
 */
public class Student extends Person {
	protected String id;
	protected String grade;
	protected ArrayList<Double> marks = new ArrayList<Double>();
	protected ArrayList<Boolean> presence = new ArrayList<Boolean>();

	/**
	 * @param id: The student id of the student
	 * @param grade: The grade of the student
	 * @param name: The name of the student:
	 * @param address: The address of the student
	 */
	public Student(String studentarr, String studentarr2, String name, String address) {
		this.id = studentarr;
		this.grade = studentarr2;
		this.name = name;
		this.address = address;
		
	}

	/**
	 * Gets the mark at a specific index
	 * @param x: index to get the mark at
	 * @return: The mark at the given index
	 */
	public double getMarks(int x) {
		return marks.get(x);
	}
	
	/**
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}
	
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Adds mark to a student class
	 * @param x
	 */
	public void addMark(double x) {
		marks.add(x);
	}

	/**
	 * Adds all the average marks up and divides by the number of marks to find the average mark
	 * @return: average mark of the student
	 */
	public double getAverageMark() {
		double sum = 0;
		if (!marks.isEmpty()) {
			for (Double mark : marks) {
				sum += mark;
			}
			return sum / marks.size();
		}
		
		return sum;

	}
	

	
	/**
	 * adds presence to the student classes
	 * @param a
	 */
	public void addPresence(boolean a) {
		presence.add(a);
	}
	
    /**
     *@return string object name of student
     */
    @Override
    public String toString() {
        return "Student's name : " + name;
    }

}

