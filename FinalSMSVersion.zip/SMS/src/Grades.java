import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * @author Kevin Wang, Piali Roy
 *
 */
/**
 * @author Kevin Wang
 *
 */
public class Grades extends JFrame implements ActionListener {
	// declare variables
	private JTable table;
	private JTextField assignmentText, removeText;
	private JButton addAssignment;
	private JButton finish, remove, save;
	private ArrayList<String> studentNames = new ArrayList<String>();
	private ArrayList<Student> students = new ArrayList<Student>();
	private ArrayList<Double> grades = new ArrayList<Double>();
	private ArrayList<Double> studentAverage = new ArrayList<Double>();
	private ArrayList<String> assignments = new ArrayList<String>();
	private ArrayList<String> init = new ArrayList<String>();
	private Classroom classroom;

	private JLabel label;
	private DefaultTableModel model;
	private String account;
	private static final long serialVersionUID = 1;
	private static final Logger LOGGER = Logger.getLogger(AddStudent.class.getName());

	/**
	 * handles GUI of grades window
	 * 
	 * @param title
	 * @param account
	 */
	public Grades(String title, String account) {
		super(title);
		this.account = account;
		classroom = new Classroom(account);
		students = classroom.getStudents();

		// makes arraylist of student names
		for (int b = 0; b < classroom.getStudents().size(); b++) {
			studentNames.add(students.get(b).getName());
		}

		model = new DefaultTableModel();
		table = new JTable(model);

		model.addColumn("Assignment"); // adds assignment column
		model.addRow(new Object[] { "Average" }); // add row column

		for (int start = 0; start < studentNames.size(); start++) {
			model.addColumn(studentNames.get(start));
		}

		try {
			BufferedReader reader = new BufferedReader(new FileReader("classroom/" + getName() + "/assignments.txt"));
			String line = reader.readLine();
			while (line != null) {
				model.addRow(new Object[] { line });
				line = reader.readLine();
			}
			reader.close();
		}

		catch (IOException e1) {
			e1.printStackTrace();
		}

		for (int k = 1; k < model.getRowCount(); k++) {
			init.add(model.getValueAt(k, 0).toString());
		}

		// iterates through all the assignment names and grades from text files and displays them to screen
		for (int i = 0; i < init.size(); i++) {
			String assName = init.get(i);
			for (int j = 0; j < studentNames.size(); j++) {
				try {
					BufferedReader reader = new BufferedReader(
							new FileReader("classroom/" + getName() + "/student/" + studentNames.get(j) + ".txt"));
					reader.readLine();
					System.out.println(studentNames.get(j));

					String line = reader.readLine();
					while (line != null) {
						String[] arr = line.split(";");
						//System.out.println(line);
						//System.out.println(arr[0]);
						//System.out.println(arr[1]);
						//System.out.println(assName);

						if (arr[1].equals(assName)) {
							//System.out.println(arr[0]);
							//System.out.println("equals!");

							model.setValueAt(arr[0], i + 1, j + 1);
						}

						line = reader.readLine();

					}
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}

		table.setRowHeight(70);

		// sets scroll bar to our files
		new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		table.setPreferredScrollableViewportSize(new Dimension(900, 350));
		table.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(table); // can scroll

		add(scrollPane);

		// assignment button
		addAssignment = new JButton("Add Assignment");
		addAssignment.setBackground(Color.GRAY);
		addAssignment.addActionListener(this);
		addAssignment.setFont(new Font("Serif", Font.BOLD, 17));
		add(addAssignment);

		assignmentText = new JTextField();
		assignmentText.setPreferredSize(new Dimension(150, 35));
		add(assignmentText);

		// remove button
		remove = new JButton("Remove Assignment");
		remove.setBackground(Color.GRAY);
		remove.addActionListener(this);
		remove.setFont(new Font("Serif", Font.BOLD, 17));
		add(remove);

		removeText = new JTextField();
		removeText.setPreferredSize(new Dimension(180, 35));
		add(removeText);

		label = new JLabel("");
		label.setPreferredSize(new Dimension(150, 35));
		add(label);

		// average button
		finish = new JButton("Calculate Average");
		finish.setBackground(Color.GRAY);
		finish.addActionListener(this);
		finish.setFont(new Font("Serif", Font.BOLD, 17));
		add(finish);

		// save info button
		save = new JButton("Save Info");
		save.setBackground(Color.GRAY);
		save.addActionListener(this);
		save.setFont(new Font("Serif", Font.BOLD, 17));
		add(save);

	}
 
	/**
	 * returns account name of the class
	 *@return this.account
	 */
	public String getName() {
		return this.account;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		try {

			if (e.getSource() == addAssignment) {
				// the added assignment does not have a name
				if (assignmentText.getText().equals("")) {
					label.setText("Input name"); // tell user to input a name
					JOptionPane.showMessageDialog(null, "Please Input data into the assignment field", "Grades",
							JOptionPane.WARNING_MESSAGE);
				}

				else { // add the assignment
					if (init.contains(assignmentText.getText())) { // handles if the assignment is already present
						JOptionPane.showMessageDialog(null, "Assignment already added", "Grades",
								JOptionPane.WARNING_MESSAGE);
					} else {
						assignments.add(assignmentText.getText());

						model.addRow(new Object[] { assignmentText.getText() });
						try {
							BufferedWriter writer = new BufferedWriter(
									new FileWriter("classroom/" + getName() + "/assignments.txt", true));
							writer.write(assignmentText.getText());
							writer.write("\n");
							writer.close();
						} catch (IOException e1) {

						}
						assignmentText.setText(""); // let the user know
						JOptionPane.showMessageDialog(null, "Successfully Added Assignment", "login",
								JOptionPane.INFORMATION_MESSAGE);
						label.setText("Added Assignment!");
					}

				}
			}

			if (e.getSource() == remove) { // remove an assignment

				if (removeText.getText().equals("Average Mark")) {
					label.setText("Invalid to remove"); // cant remove the average mark row
					JOptionPane.showMessageDialog(null, "Cannot remove average mark", "login",
							JOptionPane.INFORMATION_MESSAGE);
				}

				else { // delete it

					// find the row to delete
					for (int start = 1; start < model.getRowCount(); start++) { // loop through rows
						if (table.getModel().getValueAt(start, 0).equals(removeText.getText())) { // if the row is to be
																									// deleted
							String names = "";
							((DefaultTableModel) table.getModel()).removeRow(start); // remove that row

							// LOGGER.info(names);
							label.setText("Removed Assignment!");
							JOptionPane.showMessageDialog(null, "Removed Assignment", "Grades",
									JOptionPane.INFORMATION_MESSAGE);

						}
					}
					
					for(int i = 0; i > students.size(); i++) {
						classroom.removeGrade(students.get(i), removeText.getText() );
					}

				}

				removeText.setText("");

			}

			if (e.getSource() == finish) { // handles the finish button

				grades.clear();
				studentAverage.clear();
				assignments.clear();

				// get grades from row
				for (int i = 1; i < model.getColumnCount(); i++) {
					for (int j = 1; j < model.getRowCount(); j++) {
						Double grade = Double.valueOf(model.getValueAt(j, i).toString());
						grades.add(grade);

					}
				}

				// System.out.println(grades);

				int counter = 0;
				double averages = 0;

				// calculate the students averages
				for (int one = 0; one < grades.size(); one++) {
					counter++;
					averages += grades.get(one);
					if ((counter % (model.getRowCount() - 1)) == 0) {
						studentAverage.add(averages / (model.getRowCount() - 1));
						averages = 0;
					}
				}

				// System.out.println("Rows" + (model.getRowCount() - 1));

				// display
				int counter2 = 0;
				for (int l = 1; l < model.getColumnCount(); l++) {
					// System.out.println(studentNames.get(counter2) + " has an average of " +
					// studentAverage.get(counter2));
					model.setValueAt(studentAverage.get(counter2), 0, l);
					counter2++;
				}

			}

			if (e.getSource() == save) {

				account = this.getName();
				Classroom classroom = new Classroom(account);

				// amount of grades there are
				// students that have each grade
				// assignment each grade is from

				// get assignment names
				for (int k = 1; k < model.getRowCount(); k++) {
					assignments.add(model.getValueAt(k, 0).toString());
				}

				// System.out.println(assignments);

				// amount of columns
				for (int a = 1; a < model.getColumnCount(); a++) {
					System.out.println(students.get(a - 1).getName()); // print students

					// loop through rows
					for (int b = 1; b < model.getRowCount(); b++) {
						classroom.removeGrade(students.get(a-1), assignments.get(b-1));
						classroom.addGrade(students.get(a - 1), Double.valueOf(model.getValueAt(b, a).toString()),
								assignments.get(b - 1)); // store grade in student folder
						System.out.println(assignments.get(b - 1) + ": "); // print to console
						System.out.print(Double.valueOf(model.getValueAt(b, a).toString()));

					}
				}

				JOptionPane.showMessageDialog(null, "Grade added successfully!", "Grades",
						JOptionPane.INFORMATION_MESSAGE);
			}
		}

		// if grade entered is not number
		catch (NumberFormatException err) {
			err.printStackTrace();
			label.setText("Use number for grades");
			JOptionPane.showMessageDialog(null, "Please use numbers for grades", "Grades",
					JOptionPane.INFORMATION_MESSAGE);
		}
		// when grade is not entered in a section
		catch (IndexOutOfBoundsException err) {
			err.printStackTrace();
			label.setText("Enter in all fields");
			JOptionPane.showMessageDialog(null, "Please use numbers for grades", "Please enter all fields",
					JOptionPane.INFORMATION_MESSAGE);
		}

		catch (NullPointerException err) {
			err.printStackTrace();
			label.setText("Enter in all fields");
			JOptionPane.showMessageDialog(null, "Enter in all fields", "Please enter all fields",
					JOptionPane.INFORMATION_MESSAGE);

		}

	}
}
