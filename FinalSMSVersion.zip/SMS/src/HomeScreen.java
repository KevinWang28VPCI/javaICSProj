import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

/*
 *  Resources used:
 *  	https://chortle.ccsu.edu/java5/Notes/chap60/ch60_1.html (CHAPTER 60 � Swing JTextFields and JLabels)
 */

/**
 * Handles the home screen of the SMS
 * @author Kevin Wang, Piali Roy
 *
 */
public class HomeScreen extends JFrame implements ActionListener // adds JLabels to home screen + buttons
{
	private JPanel contentPane;
	private JButton btnStart;
	private static JLabel schoolTitle;
	private static JLabel txtAuthor;
	private static JLabel txtCourse;
	private static JLabel txtTeacher;
	private static JLabel lblVersion;
    private static final long serialVersionUID = 1;
    private static final Logger LOGGER = Logger.getLogger(AddStudent.class.getName());


	/**
	 * Handles the GUI part of the homescreen
	 */
	public HomeScreen() {
		setBackground(Color.LIGHT_GRAY);
		setForeground(Color.LIGHT_GRAY);
		setTitle("School Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 950, 500);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		schoolTitle = new JLabel("School Management System");
		schoolTitle.setFont(new Font("Yu Gothic Medium", Font.PLAIN, 37));
		schoolTitle.setBounds(215, 100, 490, 60);
		contentPane.add(schoolTitle);

		btnStart = new JButton("Start");
		btnStart.setFont(new Font("Rockwell", Font.PLAIN, 17));
		btnStart.setBounds(350, 170, 185, 75);
		contentPane.add(btnStart);

		txtAuthor = new JLabel("Author: Kevin and Piali");
		txtAuthor.setBounds(10, 335, 200, 20);
		contentPane.add(txtAuthor);

		txtCourse = new JLabel("Course: ICS3U7 - 02");
		txtCourse.setBounds(10, 360, 120, 20);
		contentPane.add(txtCourse);

		txtTeacher = new JLabel();
		txtTeacher.setText("Teacher: Ms. Xie");
		txtTeacher.setBounds(10, 385, 120, 20);
		contentPane.add(txtTeacher);

		lblVersion = new JLabel("Version: 2020-01-02");
		lblVersion.setBounds(10, 10, 200, 15);
		contentPane.add(lblVersion);

		btnStart.addActionListener(this);

	}

	/**
	 * Initialzes the base files needed to start runnign the project
	 */
	public void Initialization() {
		try {
			// creates username and pass files
			File users = new File("User Names.txt");
			File passes = new File("Passwords.txt");

			// creates classroom directory
			String classDir = "classroom";
			File file = new File(classDir);

			// checks if files were already created or not
			if (passes.createNewFile()) {
				LOGGER.info("Password text file created");
			} else {
				LOGGER.info("Password text file was already created");

			}

			if (!file.exists()) {
				file.mkdirs();
				LOGGER.info("Classroom directory created");
			} else {
				LOGGER.info("Classroom directory was already created");

			}
			

			if (users.createNewFile()) {
				LOGGER.info("Username text file created");
			} else {
				LOGGER.info("Username text file was already created");

			}

		}

		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnStart) {
			LoginPage loginPage = new LoginPage();
			loginPage.loadLoginPage();
			this.dispose();

		}

	}

}

