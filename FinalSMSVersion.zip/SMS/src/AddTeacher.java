import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * Add text to tell user if student has been properly created
 * Check to see if all fields have been filled before creating a student
 */

public class AddTeacher extends JFrame implements ActionListener
{
	private JLabel teacherLabel, created, nameLabel, specialtyLabel, addressLabel, numberLabel;
	private JButton addInfo, remove;
	private JTextField name, specialty, number, address;
	private String account;
    private static final Logger LOGGER = Logger.getLogger(AddStudent.class.getName());
    private static final long serialVersionUID = 1;

	/** handles the GUI of addteacher given the title and acccount names
	 * @param title
	 * @param account
	 */
	public AddTeacher(String title , String account)
	{
		super(title);
		this.account = account;
		setLayout(null);
		
		//MenuPage menuPage = new MenuPage(null, null);
		//System.out.println(menuPage.getName());
		
		teacherLabel = new JLabel("Enter Teacher information");
		teacherLabel.setBounds(100 , 0 , 200 , 20);
		teacherLabel.setFont(new Font("Serif", Font.BOLD, 17));
		add(teacherLabel);
		
		nameLabel = new JLabel("Enter name:");
		nameLabel.setBounds(40 , 50 , 100 , 20);
		nameLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(nameLabel);
		
		name = new JTextField();
		name.setBounds(120 , 50 , 100 , 20);
		add(name);
		
		specialtyLabel = new JLabel("Enter specialty:");
		specialtyLabel.setBounds(40 , 90 , 100 , 20);
		specialtyLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(specialtyLabel);
		
		specialty = new JTextField();
		specialty.setBounds(140 , 90 , 100 , 20);
		add(specialty);
		
		addressLabel = new JLabel("Enter address:");
		addressLabel.setBounds(40 , 130 , 150 , 20);
		addressLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(addressLabel);
		
		address = new JTextField();
		address.setBounds(140 , 130 , 100 , 20);
		add(address);
		
		numberLabel = new JLabel("Enter phone number:");
		numberLabel.setBounds(40 , 170 , 150 , 20);
		numberLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(numberLabel);

		number = new JTextField();
		number.setBounds(170 , 170 , 100 , 20);
		add(number);
		
		addInfo = new JButton ("Add");
		addInfo.setBounds(40 , 210 , 75 , 30);
		addInfo.setBackground(Color.GRAY);
		addInfo.addActionListener(this);
		add(addInfo);
		
		remove = new JButton ("Remove");
		remove.setBounds(120 , 210 , 110 , 30);
		remove.setBackground(Color.GRAY);
		remove.addActionListener(this);
		add(remove);
		
		created = new JLabel("");
		created.setBounds(40 , 235 , 250 , 30);
		add(created);
		
	}

	public String getName()
	{
		return this.account;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		

		if (e.getSource() == addInfo)
		{
			String teacherName = name.getText();
			String teacherSpecialty = specialty.getText();
			String teacherAddress = address.getText();
			String teacherNumber = number.getText();
			System.out.println(teacherName + teacherSpecialty + teacherAddress + teacherNumber);
			
			
			if (teacherName.equals("") || teacherSpecialty.equals("") || teacherAddress.equals("") || teacherNumber.equals(""))
			{
				JOptionPane.showConfirmDialog(null, "Please enter all text in all fields", "Create teacher account", JOptionPane.WARNING_MESSAGE);
				created.setText("Enter all fields of text");
				LOGGER.warning("User did not enterall text in fields");

			}
			
			else
			{
				created.setText("");

				Teacher teacher = new Teacher(teacherName , teacherAddress , teacherSpecialty, teacherNumber);
				
				Classroom classroom = new Classroom(getName());
				if(classroom.addTeacher(teacher)) {
					JOptionPane.showConfirmDialog(null, "Successfully teacher account", "Create teacher account", JOptionPane.WARNING_MESSAGE);
					created.setText("teacher Succesfully created!");
					created.setForeground(Color.GREEN);
					LOGGER.info(teacher + " was created");
				}
				else {
					JOptionPane.showConfirmDialog(null, "Teacher account already created", "Create teacher account", JOptionPane.WARNING_MESSAGE);
					created.setText("Teacher not created!");
					created.setForeground(Color.RED);
					LOGGER.warning(teacher + " already created");
				}
				
				classroom.updateClassroom();
				
				name.setText("");
				specialty.setText("");
				address.setText("");
				number.setText("");
			}
			
			if (e.getSource() == remove)
			{
				Classroom classroom = new Classroom(getName());
				if(classroom.removeTeacher(name.getText())) {
					JOptionPane.showConfirmDialog(null, name.getText() + " was deleted successfully", "Delete Student Account", JOptionPane.INFORMATION_MESSAGE);
					created.setText("Removed Teacher");
					LOGGER.info(name.getText() + " was deleted");

				}
				else {
					JOptionPane.showConfirmDialog(null, "Error, Student account may not exist", "Delete Student Account", JOptionPane.WARNING_MESSAGE);
					created.setText("Error removing Teacher");
					LOGGER.warning(name.getText() + " may not exist");


				}
				
				name.setText("");
				specialty.setText("");
				number.setText("");
				address.setText("");
			}
		}
	}
}


