import java.io.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Classroom class that manages all the students and teachers of a given class
 * 
 * @author Kevin Wang
 *
 */
public class Classroom {
	
	// declare variables
	private String classroomName;
	private static char key = 'Q';
	private ArrayList<Teacher> teachers = new ArrayList<Teacher>();
	private ArrayList<Student> students = new ArrayList<Student>();
	private static final Logger LOGGER = Logger.getLogger(AddStudent.class.getName());

	/**
	 * @param classroomName
	 */
	public Classroom(String classroomName) {
		this.classroomName = classroomName;
		updateClassroom();
	}

	/**
	 * updates the classroom after any students and teachers are added and ads them
	 * to their respectivce array lists
	 */
	public void updateClassroom() { // method to iterate through all the classroom student files and put them into
									// the arraylist of the teachers and students, put this into the constructor

		// file initialization
		File teacherData = new File("classroom/" + classroomName + "/teacher/");
		File studentData = new File("classroom/" + classroomName + "/student/");
		File attendanceData = new File("classroom/" + classroomName + "/attendance/");
		File assignmentData = new File("classroom/" + classroomName + "/assignments.txt");
		File[] studentDataListing = studentData.listFiles();
		File[] teacherDataListing = teacherData.listFiles();

		try {
			if (assignmentData.createNewFile()) {
				LOGGER.info("assignments text file created");
			} else {
				LOGGER.info("assignments  text file was already created");

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// maybe turn into try/catch?
		if (!teacherData.exists()) {
			teacherData.mkdirs();
			LOGGER.info("Teacher directory created");
		} else {
			LOGGER.info("Teacher directory already created");

		}

		if (!studentData.exists()) {
			studentData.mkdirs();
			LOGGER.info("Student directory created");
		} else {
			LOGGER.info("Student directory already created");

		}

		if (!attendanceData.exists()) {
			attendanceData.mkdirs();
			LOGGER.info("Attendance directory created");

		} else {
			LOGGER.info("Attendance directory already created");

		}

		// traverse through student files and make each file a student object and add them to the class
		if (studentDataListing != null) {
			for (File child : studentDataListing) {
				if (child.getName().toLowerCase().endsWith(".txt")) {
					try {
						BufferedReader reader = new BufferedReader(new FileReader(child));
						String line = reader.readLine();
						String unencrypted = Xorcrypt(key, line);
						String[] studentarr = unencrypted.split(";");
						Student student = new Student(studentarr[0], studentarr[1], studentarr[2], studentarr[3]);

						reader.close();
						students.add(student);
						// System.out.println(student);

						File attendance = new File(
								"classroom/" + classroomName + "/attendance/" + studentarr[0] + ".txt");

						if (!attendance.exists()) {
							LOGGER.info("Attendance for student" + attendance + " was created");
						} else {
							LOGGER.info("Attendance for student" + attendance + " was already created");

						}

					} catch (IOException ex) {
						// System.out.println("error");
						ex.printStackTrace();
					}

				} else {
					LOGGER.info("The file is not a proper text file!");
				}
			}

			// traverse through teacher files and make each file a teacher object and add them to the class
			if (teacherDataListing != null) {
				for (File child : teacherDataListing) {
					if (child.getName().toLowerCase().endsWith(".txt")) {
						try {
							BufferedReader reader = new BufferedReader(new FileReader(child));
							String line = reader.readLine();
							String unencrypted = Xorcrypt(key, line);
							String[] teacherarr = unencrypted.split(";"); // white space regex
							Teacher teacher = new Teacher(teacherarr[0], teacherarr[1], teacherarr[2], teacherarr[3]);
							reader.close();

							teachers.add(teacher);

						} catch (IOException ex) {
							LOGGER.info("No teacher classes found!");
						}

					}

					else {
						LOGGER.warning("File not txt file, file may be tampered with");
					}

				}

			}
		}

	}

	/**
	 * Xor algorithm(exclusive or) encryption algorithm. Works the same with
	 * encryption and decryption
	 * 
	 * @param key:     The key to encrypt/decrypt with the message with
	 * @param message: the string to encrypt/decrypt
	 * @return: the encrypted/decrypted string
	 */
	public String Xorcrypt(char key, String message) {
		char xorKey = key;
		String outputString = "";
		int len = message.length();

		for (int i = 0; i < len; i++) {
			outputString = outputString + Character.toString((char) ((char) message.charAt(i) ^ xorKey)); // where the actual xor happens
		}

		return outputString;
	}

	/**
	 * Updates the attendance for a given student
	 * 
	 * @param student
	 * @param status
	 * @param date
	 */
	public void updateAttendance(Student student, String status, String date) {
		String name = student.getName();
		File attendanceData = new File("classroom/" + classroomName + "/attendance/" + name + ".txt");
		try {
			BufferedWriter grade = new BufferedWriter(new FileWriter(attendanceData, true)); // true to append content
																								// to the
			// file
			grade.write(date + ": " + status); // adds attendance to the user
			grade.write("\n");
			grade.close();
			LOGGER.info("Attendance for student" + name + " was already created");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Removes a given student from a classrooms:
	 * 
	 * @param name
	 * @return deleted
	 */
	public boolean removeStudent(String name) {
		File studentData = new File("classroom/" + classroomName + "/student/");
		File attendanceData = new File("classroom/" + classroomName + "/attendance/");
		File[] attendanceDataListing = attendanceData.listFiles();
		File[] studentDataListing = studentData.listFiles();

		// deletes the student file
		boolean deleted = false;
		if (studentDataListing != null) {
			for (File child : studentDataListing) {
				String fileName = child.getName();
				if (fileName.equals(name + ".txt")) {
					try {
						child.delete();
						deleted = true;
						LOGGER.info("removed " + fileName);

					} catch (Exception ex) {
						ex.printStackTrace();

					}

				}
			}
		}

		// deletes the attendance file
		if (attendanceDataListing != null) {
			for (File child2 : attendanceDataListing) {
				String fileName2 = child2.getName();
				if (fileName2.equals(name + ".txt")) {
					try {
						child2.delete();
						LOGGER.info("removed " + fileName2);

					} catch (Exception ex) {
						ex.printStackTrace();

					}

				}
			}
		}

		// returns if the deletion has suceeded or not
		return deleted;

	}
	/**
	 * gets how many times a student has been present
	 * @return response
	 */
	public String getPresence(String student) {
		int present = 0;
		int late = 0;
		int absent = 0;
		
		String response = "";

		try {
			BufferedReader reader = new BufferedReader(new FileReader("classroom/" + classroomName + "/attendance/" + student + ".txt") );
			String line = reader.readLine();
			while(line != null) {
				String[] arr = line.split(" ");
				if (arr[arr.length-1].equals("Present")) {
					present +=1;
				}
				else if (arr[arr.length-1].equals("Late")) {
					late +=1;
				}
				else if (arr[arr.length-1].equals("Absent")) {
					absent +=1;
				}
				line = reader.readLine();
			}
			reader.close();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		response += "Absent: " + absent + " Present: " + present + " Late " + late; 
		return response;
	}
	
	/**
	 * removes a given teacher from a class, and returns if the teacher was deleted
	 * successfully or not
	 * 
	 * @param name
	 * @return deleted
	 */
	public boolean removeTeacher(String name) {
		File teacherData = new File("classroom/" + classroomName + "/teacher/");
		File[] teacherDataListing = teacherData.listFiles();
		boolean deleted = false;
		if (teacherDataListing != null) {
			for (File child : teacherDataListing) {
				String fileName = child.getName();
				if (fileName.equals(name + ".txt")) {
					try {
						child.delete();
						deleted = true;
						LOGGER.info("removed " + fileName);

					} catch (Exception ex) {
						ex.printStackTrace();

					}

				}
			}
		}

		return deleted;

	}

	/**
	 * returns all the teachers in a given class
	 * 
	 * @return teachers
	 */
	public ArrayList<Teacher> getTeachers() {
		return teachers;
	}

	/**
	 * adds a grade to a student
	 * 
	 * @param student
	 * @param mark
	 * @param string
	 */
	public void addGrade(Student student, double mark, String string) {
		String temp = student.getName();
		String fileName = "classroom/" + classroomName + "/student/" + temp + ".txt";
		try {
			BufferedWriter grade = new BufferedWriter(new FileWriter(fileName, true)); // true to append content to the
			grade.write(mark + ";" + string);
			grade.write("\n");
			grade.close();

			LOGGER.info(mark + " was added to " + student);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * removes a specified grade from a student
	 * @param student
	 * @param identifier
	 */
	public void removeGrade(Student student, String identifier) {
		String temp1 = student.getName();
		int n = 0;
		File fileName = new File("classroom/" + classroomName + "/student/" + temp1 + ".txt");
		File tempFile = new File("classroom/" + classroomName + "/student/" + temp1 + "Temp" + ".txt");

		// you cannot remove a line from a file, so here we create a new file with the line we want to remove
		try {
			BufferedReader grade = new BufferedReader(new FileReader(fileName));
			BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile));
			String line = grade.readLine();
			while (line != null) {
				String[] placeHolder = line.split(";");
				// System.out.println(line +" line");
				// System.out.println(identifier);

				if(n == 0) {
					n +=1;
					temp.write(line + "\n");
					line = grade.readLine();

					continue;
				}
				
				if(placeHolder[1].equals(identifier)) {
					line = grade.readLine();

					continue;
				}
				temp.write(line + "\n");
				line = grade.readLine();

			}

			grade.close();
			temp.close();
			fileName.delete();
			tempFile.renameTo(fileName);

			LOGGER.info("grade " + identifier + " was removed from " + student);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * adds a given teacher to the classroom and returns if it was successfully
	 * created or not
	 * 
	 * @param teacher
	 * @return created
	 */
	public boolean addTeacher(Teacher teacher) {
		boolean created = true;
		String temp = teacher.getName();
		try {
			File teacherData = new File("classroom/" + classroomName + "/teacher/" + temp + ".txt"); // create teacher file
			if (teacherData.createNewFile()) {
				LOGGER.info("file " + temp + " was created");
			} else {
				LOGGER.info("file " + temp + " was already created");
				created = false;

			}
		} catch (IOException e) {
			LOGGER.info("file " + temp + " had an error being created");

		}

		if (created) {
			try { // write teacher data to teacher file
				BufferedWriter teacherText = new BufferedWriter(
						new FileWriter("classroom/" + classroomName + "/teacher/" + temp + ".txt"));
				String encTeacherData = Xorcrypt(key, (String) (teacher.specialty + ";" + teacher.phoneNumber + ";"
						+ teacher.name + ";" + teacher.address));
				teacherText.write(encTeacherData);
				teacherText.write("\n");
				teacherText.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return created;

	}

	/**
	 * adds a given student to the classroom and returns if it was successfully
	 * created or not
	 * 
	 * @param student
	 * @return created
	 */
	public boolean addStudent(Student student) {
		boolean created = true;
		String temp = student.getName();
		// create the data file for the student
		try {
			File studentData = new File("classroom/" + classroomName + "/student/" + temp + ".txt");
			if (studentData.createNewFile()) {
				LOGGER.info("file " + student.name + " was created");
			} else {
				LOGGER.info("file " + student.name + " was already created");
				created = false;

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (created) {
			try { // create student data for the file
				BufferedWriter studentText = new BufferedWriter(
						new FileWriter("classroom/" + classroomName + "/student/" + student.name + ".txt"));
				String encStudentText = Xorcrypt(key,
						(String) (student.id + ";" + student.grade + ";" + student.name + ";" + student.address));
				studentText.write(encStudentText);
				studentText.write("\n");
				studentText.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

			try {
				File attendanceData = new File("classroom/" + classroomName + "/attendance/" + student.name + ".txt");
				if (attendanceData.createNewFile()) {
					LOGGER.info("attendance file for " + student.name + " already created");
				} else {
					LOGGER.warning("attendance file for " + student.name + " was already created");

				}
			}

			catch (IOException e) {
				e.printStackTrace();
			}
		}
		return created;

	}

	/**
	 * returns arraylist of students
	 * 
	 * @return students
	 */
	public ArrayList<Student> getStudents() {
		return students; // returns arraylist of students
	}
}
