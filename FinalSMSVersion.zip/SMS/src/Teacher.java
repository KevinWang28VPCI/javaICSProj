/** Represents a Teacher
 * @author Kevin Wang
 *
 */
public class Teacher extends Person {
	// special variables for teacher
	protected String specialty;
	protected String phoneNumber;

	/**
	 * Creates a new Teacher Object
	 * 
	 * @param name
	 * @param address
	 * @param specialty
	 * @param phoneNumber
	 */
	public Teacher(String name, String address, String specialty, String phoneNumber) {
		this.name = name;
		this.address = address;
		this.specialty = specialty;
		this.phoneNumber = phoneNumber;
	}

	/**
	 * returns name of teacher
	 * @return this.name
	 */
	
	
	/**
	 * returns specialty of teacher
	 * @return this.specialty
	 */
	public String getSpecialty() {
		return this.specialty;
	}

	/**
	 * return teacher phonenumber
	 * @return this.phoneNumber
	 */
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
    /**
     *@return string object name of teacher
     */
    @Override
    public String toString() {
        return "Name of the Teacher: " + getName();
    }
}
