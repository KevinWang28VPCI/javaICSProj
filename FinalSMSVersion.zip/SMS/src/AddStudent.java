import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.logging.Logger;


/**
 * Handles the add student function of the SMS
 * @author Kevin Wang, Piali Roy
 *
 */
public class AddStudent extends JFrame implements ActionListener
{
	// initialize variables
	private JButton add, remove;
	private static JLabel accountLabel, gradeLabel, idLabel, addressLabel, nameLabel;
	private JLabel created;
	private JTextField name,grade,id,address;
	private String account;
    private static final Logger LOGGER = Logger.getLogger(AddStudent.class.getName());
    private static final long serialVersionUID = 1;

	
	/**
	 * Handles the add student gui of the SMS
	 * @param title
	 * @param account
	 */
	public AddStudent(String title , String account)
	{
		super(title);
		
		setLayout(null);
		this.account = account;
		accountLabel = new JLabel("Enter student information");
		accountLabel.setBounds(100 , 0 , 200 , 20);
		accountLabel.setFont(new Font("Serif", Font.BOLD, 17));
		add(accountLabel);
		
		// name label
		nameLabel = new JLabel("Enter name:");
		nameLabel.setBounds(40 , 50 , 100 , 20);
		nameLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(nameLabel);
		
		name = new JTextField();
		name.setBounds(120 , 50 , 100 , 20);
		add(name);
		
		//grade label
		gradeLabel = new JLabel("Enter Grade:");
		gradeLabel.setBounds(40 , 90 , 100 , 20);
		gradeLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(gradeLabel);
		
		grade = new JTextField();
		grade.setBounds(120 , 90 , 100 , 20);
		add(grade);
		
		// id label
		idLabel = new JLabel("Enter id:");
		idLabel.setBounds(40 , 130 , 150 , 20);
		idLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(idLabel);
		
		id = new JTextField();
		id.setBounds(100 , 130 , 100 , 20);
		add(id);
		
		// address label
		addressLabel = new JLabel("Enter Address:");
		addressLabel.setBounds(40 , 170 , 150 , 20);
		addressLabel.setFont(new Font("Serif", Font.BOLD, 13));
		add(addressLabel);
		
		address = new JTextField();
		address.setBounds(130 , 170 , 100 , 20);
		add(address);
		
		// add button
		add = new JButton ("Add");
		add.setBounds(40 , 210 , 75 , 30);
		add.setBackground(Color.GRAY);
		add.addActionListener(this);
		add(add);
		
		// remove button
		remove = new JButton ("Remove");
		remove.setBounds(120 , 210 , 110 , 30);
		remove.setBackground(Color.GRAY);
		remove.addActionListener(this);
		add(remove);
		
		// created button
		created = new JLabel("");
		created.setBounds(40 , 235 , 250 , 30);
		add(created);
	}


	/**
	 * returns the account name
	 *@return this.account
	 */
	public String getName()
	{
		return this.account;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		try
		{
			
			if (e.getSource() == add)
			{
			

				String studentName = name.getText();
				String studentGrade = grade.getText();
				String studentID = id.getText();
				String studentAddress = address.getText();
				
				// checks if the fields are empty
				if (name.getText().equals("") || grade.getText().equals("") || id.getText().equals("") || address.getText().equals(""))
				{
					JOptionPane.showConfirmDialog(null, "Please enter all text in all fields", "Create student account", JOptionPane.WARNING_MESSAGE);
					created.setText("Enter all fields of text");
					LOGGER.warning("User did not enterall text in fields");
				}
					
				
				else
				{
					created.setText("");
					// creates a student and uses the classroom setter method to add a student
					Student student = new Student(studentID , studentGrade , studentName , studentAddress);
					Classroom classroom = new Classroom(getName());
					if(classroom.addStudent(student)) {
						JOptionPane.showConfirmDialog(null, "Successfully created account", "Create student account", JOptionPane.WARNING_MESSAGE);
						created.setText("Student Succesfully created!");
						created.setForeground(Color.GREEN);
						LOGGER.info(student + " was created");
					}
					else {
						JOptionPane.showConfirmDialog(null, "Student account already created", "Create student account", JOptionPane.WARNING_MESSAGE);
						created.setText("Student not created!");
						created.setForeground(Color.RED);
						LOGGER.warning(student + " already created");
				
					}
					
					// updates classroom
					classroom.updateClassroom();
					
					//sets text fields back to blank
					name.setText("");
					grade.setText("");
					id.setText("");
					address.setText("");
				}
				
			}	
			
			if (e.getSource() == remove) // remove student
			{
				Classroom classroom = new Classroom(getName());
				if(classroom.removeStudent(name.getText())) { // uitlizes remove student setter function
					created.setText("Removed Student");
					LOGGER.info(name.getText() + " was deleted");

				}
				else { // handles condition where student account does not exist
					JOptionPane.showConfirmDialog(null, "Error, Student account may not exist", "Delete Student Account", JOptionPane.WARNING_MESSAGE);
					created.setText("Error removing student");
					LOGGER.warning(name.getText() + " may not exist");


				}
				
				name.setText("");
				grade.setText("");
				id.setText("");
				address.setText("");
			}
		}
		
		catch(NumberFormatException err)
		{
			System.out.println(err.getMessage());
			JOptionPane.showConfirmDialog(null, "Error, ID and Grade is not a number", "Create Student Account", JOptionPane.WARNING_MESSAGE);
			created.setText("Invalid Grade or Student ID");
			LOGGER.warning("Id or Grade not supplied integer");

		}
	}
}


