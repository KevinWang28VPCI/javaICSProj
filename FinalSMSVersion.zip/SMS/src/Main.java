public class Main {
	/**
	 * Starts off the SMS!
	 * @param args
	 */
	public static void main(String[] args) {
		HomeScreen frame = new HomeScreen();
		frame.Initialization();
		frame.setVisible(true);
	}
}
