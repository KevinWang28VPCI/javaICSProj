import java.awt.*;
import javax.swing.JOptionPane;

import java.awt.event.*;
import java.io.*;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;

// things to add with the login screen
//	- make it so that a user cannot be created if the user name is the same as a previously stored user name

/*
 *  Resources used: 
 *  	https://beginnersbook.com/2015/07/java-swing-tutorial/  - (Simple login screen for beginners)
 */
/**
 * Login page class to store usernames and passwords and show loginpage gui
 * @author Kevin Wang, Piali Roy
 *
 */
public class LoginPage extends JFrame implements ActionListener {
	// define variables
	private String encryptedUser;
	private static JTextField userNameText, userPassText;
	private static JButton login, createUser;
	private static JLabel correctLogin, userName, loginTitle, createUserLabel;
	private JFrame loginFrame = new JFrame("User Login");
	private JPanel loginPanel = new JPanel();
    private static final long serialVersionUID = 1;
    private static final Logger LOGGER = Logger.getLogger(LoginPage.class.getName());
    private ConsoleHandler ch = new ConsoleHandler();

    // key for encryption
	private char key = 'P';

	/**
	 * Xor algorithm(exclusive or) encryption algorithm. Works the same with
	 * encryption and decryption
	 * 
	 * @param key:     The key to encrypt/decrypt with the message with
	 * @param message: the string to encrypt/decrypt
	 * @return: the encrypted/decrypted string
	 */
	
	public String Xorcrypt(char key, String message) {
		char xorKey = key;
		String outputString = "";
		int len = message.length();

		for (int i = 0; i < len; i++) {
			outputString = outputString + Character.toString((char) message.charAt(i) ^ xorKey);
		}

		return outputString;
	}

	/**
	 * Handles GUI of login Page
	 */
	public LoginPage() {
		ch.setLevel(Level.ALL);
		LOGGER.addHandler(ch);
		LOGGER.setLevel(Level.ALL);
		LOGGER.setUseParentHandlers(false);

		loginTitle = new JLabel("Login to Student Manager", JLabel.CENTER); // label
		loginTitle.setFont(new Font("Ariel", Font.BOLD, 35)); // font type and size
		loginTitle.setBounds(150, 0, 600, 75);
		loginPanel.add(loginTitle); // adds

		userName = new JLabel("User Name: ");
		userName.setFont(new Font("Ariel", Font.BOLD, 20)); // font type and size
		userName.setBounds(50, 130, 175, 25);
		loginPanel.add(userName);

		userNameText = new JTextField(10); // gets users input
		userNameText.setBounds(175, 132, 165, 25); // set bounds
		loginPanel.add(userNameText); // adds the text box

		JLabel userPass = new JLabel("Password: "); // label
		userPass.setFont(new Font("Ariel", Font.BOLD, 20)); // font type and size
		userPass.setBounds(50, 10, 900, 400);
		loginPanel.add(userPass); // adds label

		userPassText = new JPasswordField(10); // text box
		userPassText.setBounds(175, 199, 165, 25); // set bound
		loginPanel.add(userPassText); // adds text box

		login = new JButton("Login"); // login button
		login.setBounds(50, 249, 105, 25);
		login.addActionListener(this); // what happens when action is performed
		loginPanel.add(login); // adds button on panel

		createUser = new JButton("Create User"); // button to create new user
		createUser.setBounds(185, 249, 105, 25);
		createUser.addActionListener(this);
		loginPanel.add(createUser);

		correctLogin = new JLabel("");
		correctLogin.setBounds(50, 100, 300, 25);
		loginPanel.add(correctLogin);

		createUserLabel = new JLabel(
				"*To create a new account enter a user name and a password then press the Create User button");
		createUserLabel.setBounds(50, 400, 600, 30);
		loginPanel.add(createUserLabel);
		
	}

	
	// buttons events if clicked
	@Override
	public void actionPerformed(ActionEvent e) {
		
		try {

			// create bufferedWriter to write to user/pass files
			BufferedWriter userNames = new BufferedWriter(new FileWriter("User Names.txt", true));
			BufferedWriter passwords = new BufferedWriter(new FileWriter("Passwords.txt", true));

			// create bufferedReader to read to user/pass files
			BufferedReader readUsers = new BufferedReader(new FileReader("User Names.txt"));
			BufferedReader readPasswords = new BufferedReader(new FileReader("Passwords.txt"));

			boolean sameUser = false;
			String line1, line2, line3;

			// changed two lines - global within this section?
			// this way is able to check if encrypted user is same as already stored(encrypted user)
			String newEncryptedUser = Xorcrypt(key, userNameText.getText());
			
			if (e.getSource() == createUser) {

				if ((userNameText.getText().equals("") || userPassText.getText().equals(""))) // if no info in text
																								// boxes
				{
					JOptionPane.showMessageDialog(loginFrame, "Please enter info in both fields", "login",  JOptionPane.WARNING_MESSAGE);
					correctLogin.setText("Please enter information in both fields"); // ask user to enter
					correctLogin.setForeground(Color.DARK_GRAY);
					LOGGER.info("Both fields not with info");
				}

				else {

					while ((line3 = readUsers.readLine()) != null) // goes through username file
					{
						if (line3.equals(newEncryptedUser)) // if line is same as the entered (encrypted) username
						{
							sameUser = true;
							break; // escape loop
						}
					}

					if (sameUser) {
						JOptionPane.showMessageDialog(loginFrame, "This username has already been taken", "login",  JOptionPane.WARNING_MESSAGE);
						correctLogin.setText("this user name has already been taken"); // ask user to enter
						correctLogin.setForeground(Color.DARK_GRAY);
						LOGGER.info("Username has been taking");

					}

					else if (sameUser == false) // writing
					{
						int reply = JOptionPane.showConfirmDialog(loginFrame, "Are you sure you want to create this account?", "Create Account", JOptionPane.YES_NO_OPTION);
						
						if(reply == JOptionPane.YES_OPTION) {
							String newEncryptedPass = Xorcrypt(key, userPassText.getText());

							userNames.write(newEncryptedUser); // inputs the username in the username text file
							passwords.write(newEncryptedPass); // inputs the password in the password text file

							userNames.newLine();
							passwords.newLine();
							correctLogin.setText("Account successfully created"); // ask user to enter
							correctLogin.setForeground(Color.GREEN);
							LOGGER.info("Account successfully created for user " + newEncryptedUser);
							JOptionPane.showConfirmDialog(loginFrame, "Account Successfully!", "Create Account", JOptionPane.YES_NO_OPTION);
							userNameText.setText("");
							userPassText.setText("");

						}
						else {
							System.out.println("Account not Created");
							
						}

					}

				}

			}

			if (e.getSource() == login) // if user has pressed the login button
			{
				// set user and pass to false
				boolean pass = false;
				boolean user = false;

				// counters set to 0
				int count1 = 0;
				int count2 = 0;

				if (userNameText.getText().equals("") || userPassText.getText().equals("")) // if both fields are blank
																							// prompt user for info
				{
					JOptionPane.showConfirmDialog(loginFrame, "Please enter information in both fields", "Login Account", JOptionPane.WARNING_MESSAGE );
					correctLogin.setText("Please enter information in both fields");
					correctLogin.setForeground(Color.DARK_GRAY); // text color to dark gray
					LOGGER.info("Both fields not supplied with info");

				}

				else // if both text fields have info
				{
					while ((line1 = readUsers.readLine()) != null) // goes through username file
					{
						count1 += 1; // count 1 for each line read through
						encryptedUser = Xorcrypt(key, userNameText.getText());
						if (line1.equals(encryptedUser)) // if line is same as the entered username
						{
							user = true; // user = true
							break; // escape loop
						}
					}

					while ((line2 = readPasswords.readLine()) != null) // read through until nothing
					{
						count2 += 1; // count 1 for each line read

						if (count2 == count1) // if line read is equal to the line in username file where the correct
												// username was found
						{
							String encryptedPass = Xorcrypt(key, userPassText.getText());
							if (line2.equals(encryptedPass)) // check if the entered pass is the same as the
																// stored pass
							{
								pass = true; // set to true
								break; // out of loop
							}
						}
					}

					if ((user == true) && (pass == true)) // both true
					{
						LOGGER.info("Logging Success for " + userNameText.getText());
						correctLogin.setText("Correct Login Information"); // logged in
						correctLogin.setForeground(Color.green);
						JOptionPane.showMessageDialog(null, "Login Success", "Login",  JOptionPane.INFORMATION_MESSAGE);
						
						MenuPage frame = new MenuPage("Menu Page", userNameText.getText() );
					    frame.getContentPane().setBackground(Color.LIGHT_GRAY);
					    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					    frame.pack();
					    frame.setSize( 950, 500 );
					    frame.setLocationRelativeTo(null);    
					    frame.setVisible( true );
					    loginFrame.dispose();
					    

					}

					else 
					{
						JOptionPane.showConfirmDialog(loginFrame, "Wrong username or password", "Login Account", JOptionPane.WARNING_MESSAGE );
						correctLogin.setText("Incorrect Login Information");
						correctLogin.setForeground(Color.red);
						LOGGER.warning("Wrong login information for " + encryptedUser);

					}

					count1 = 0; // re-set the counters
					count2 = 0;
				}
			}

			// closes BufferedReaders and BufferedWriters
			userNames.close();
			passwords.close();
			readUsers.close();
			readPasswords.close();
		}

		catch (IOException err) // catch error
		{
			System.out.println("Error " + err.getMessage()); // prints error
		}
	}

	/**
	 * Initializes and Loads login page 
	 */
	public void loadLoginPage() {
		

		loginPanel.setBackground(Color.WHITE);

		loginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just hide the frame

		loginFrame.pack();
		loginFrame.setSize(950, 500); // set size of screen
		loginFrame.setLocationRelativeTo(null); // screen will be in middle

		loginPanel.setLayout(null); // no defined setLayout
		loginFrame.add(loginPanel); // adds panel onto frame
		
		loginFrame.setVisible(true);

	}
}