import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


/**
 * handles the add info function of the SMS
 * @author Kevin Wang, Piali Roy
 *
 */
public class AddInfo extends JFrame implements ActionListener
{
	// declare variables
	private static JLabel label;
	private JButton addTeacher;
	private JButton addStudent;
	private JButton studentDisplayInfo, teacherDisplayInfo;
	private JButton back;
	private String account;
    private static final long serialVersionUID = 1;
 
	/**
	 * Handles addinfo GUI given title and account name
	 * @param title
	 * @param account
	 */
	public AddInfo(String title , String account)
	{
		super(title);
		this.account = account;
		setLayout(null);
		
		// main label
		label = new JLabel("Add Student and Teacher Information");
		label.setBounds(175, 10 , 580 , 50);
		label.setFont(new Font("Serif", Font.BOLD, 35));
		add(label);
		
		//add teacher label
		addTeacher = new JButton("Add Teacher");
		addTeacher.setFont(new Font("Serif", Font.BOLD, 15));
		addTeacher.setBounds(400 , 100 , 140 , 40);
		addTeacher.setBackground(Color.GRAY);
		addTeacher.addActionListener(this);
		add(addTeacher);
		
		// add student label
		addStudent = new JButton("Add Student");
		addStudent.setFont(new Font("Serif", Font.BOLD, 15));
		addStudent.setBounds(400 , 175 , 140 , 40);
		addStudent.setBackground(Color.GRAY);
		addStudent.addActionListener(this);
		add(addStudent);
		
		// see students label
		studentDisplayInfo = new JButton("See Students");
		studentDisplayInfo.setFont(new Font("Serif", Font.BOLD, 15));
		studentDisplayInfo.setBounds(400 , 250 , 140 , 40);
		studentDisplayInfo.setBackground(Color.GRAY);
		studentDisplayInfo.addActionListener(this);
		add(studentDisplayInfo);
		
		// see teachers label
		teacherDisplayInfo = new JButton("See Teachers");
		teacherDisplayInfo.setFont(new Font("Serif", Font.BOLD, 15));
		teacherDisplayInfo.setBounds(400 , 325 , 140 , 40);
		teacherDisplayInfo.setBackground(Color.GRAY);
		teacherDisplayInfo.addActionListener(this);
		add(teacherDisplayInfo);
		
		// back button
		back = new JButton("<Back");
		back.setFont(new Font("Serif", Font.BOLD, 15));
		back.setBackground(Color.GRAY);
		back.setBounds(10 , 420 , 105 , 30);
		back.addActionListener(this);
		add(back);
	}	

	
	/**
	 * returns the account name
	 */
	public String getName()
	{
		return this.account;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == addTeacher)
		{
			// System.out.println(getName());
			AddTeacher frame = new AddTeacher("Add a Teacher" , getName()); // utilizes addteacher setter method
			frame.getContentPane().setBackground(Color.LIGHT_GRAY);
			frame.setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		    frame.pack();
		    frame.setSize(400 , 300);
		    frame.setLocationRelativeTo(null);
		    frame.setVisible( true );
		}
		
		if(e.getSource() == back)
		{
			MenuPage frame = new MenuPage("Menu Page", this.account ); // return back to homepage
		    frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		    frame.pack();
		    frame.setSize( 950, 500 );
		    frame.setLocationRelativeTo(null);    
		    frame.setVisible( true );
		    this.dispose();
		}
		
		if (e.getSource() == addStudent)
		{
			AddStudent frame = new AddStudent("Add Student Information" , getName()); // utilizes addstudent setter method
			frame.getContentPane().setBackground(Color.LIGHT_GRAY);
			frame.setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		    frame.pack();
		    frame.setSize(400 , 300);
		    frame.setLocationRelativeTo(null);
		    frame.setVisible( true );
		}
		
		if (e.getSource() == studentDisplayInfo)
		{
			StudentDisplay frame = new StudentDisplay("See Student Information" , getName()); // directs to student display
			frame.getContentPane().setBackground(Color.LIGHT_GRAY);
			frame.setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		    frame.pack();
		    frame.setSize(400 , 300);
		    frame.setLocationRelativeTo(null);
		    frame.setResizable(false);
		    frame.setVisible( true );
		}
		
		if (e.getSource() == teacherDisplayInfo)
		{
			TeacherDisplay frame = new TeacherDisplay("See Teacher Information" , getName()); // directs to teacher display
			frame.getContentPane().setBackground(Color.LIGHT_GRAY);
			frame.setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		    frame.pack();
		    frame.setSize(400 , 300);
		    frame.setLocationRelativeTo(null);
		    frame.setResizable(false);
		    frame.setVisible( true );
		}
		
	}
}

