import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/* resources used
 * get current date and time copied from: https://www.tutorialspoint.com/how-to-get-today-s-date-in-java8
 * JTable guide - https://www.youtube.com/watch?v=wniqpx8OQxo&t=242s
 */

/**
 * handles the attendance of the program
 * @author Kevin Wang, Piali Roy
 *
 */
public class Attendance extends JFrame implements ActionListener {

	// var declaration
	private JButton button;
	private JLabel created;
	private JComboBox<String> box;
	private JTable table;
	private ArrayList<String> presence = new ArrayList<String>();
	private DefaultTableModel model;
	private String account;
	private String currentDate;
	private ArrayList<String> names;
	private Object data[][] = {}; // no data for now
	private static String[] options = { "Present", "Late", "Absent" }; // columns headers for my table
	private static String col[] = { "Name", "Presence" }; // column headers
	private static final long serialVersionUID = 1;


	/**
	 * Constructs the GUI part of the attendance given the account name
	 * @param title
	 * @param account
	 */
	public Attendance(String title, String account) {
		super(title);
		setLayout(new BorderLayout());
		this.account = account;

		names = new ArrayList<String>(); // arrayList for student names
		box = new JComboBox<String>(options); // put the options of the combo box inside
		model = new DefaultTableModel(data, col); // table with size data and column
		table = new JTable(model);

		Classroom classroom = new Classroom(account); // get the classroom for account person is in
		System.out.println(classroom.getStudents());

		for (int b = 0; b < classroom.getStudents().size(); b++) // gets of half of array as other half is duplicate
		{
			System.out.println(classroom.getStudents().get(b).toString());
			names.add(classroom.getStudents().get(b).toString());
		}

		for (int start = 0; start < names.size(); start++) {
			// Append a row
			model.addRow(new Object[] { names.get(start) }); // add info to rows
			// put this inside the loop for bufferedReader to easily create new columns
		}

		TableColumn testColumn = table.getColumnModel().getColumn(1); // add combo boxes insdide table column
		testColumn.setCellEditor(new DefaultCellEditor(box));

		table.setRowHeight(50); // set the height of the rows to 50px

		table.setPreferredScrollableViewportSize(new Dimension(700, 500)); // set size and scrollable
		table.setFillsViewportHeight(true); // make height true
		JScrollPane scrollPane = new JScrollPane(table); // can scroll

		add(scrollPane);

		button = new JButton("Finish Selection"); // button to submit attendance
		button.setBackground(Color.GRAY);
		button.addActionListener(this);
		button.setFont(new Font("Serif", Font.BOLD, 15));
		add(button, BorderLayout.PAGE_END); // position of the button

		// set up the date
		Date date = new Date();
		String dateFormatString = "EEEEEEE, MMMMMMMM dd, yyyy";
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		currentDate = dateFormat.format(date);

		// display the date on the GUI
		JLabel label = new JLabel(currentDate);
		label.setFont(new Font("Serif", Font.BOLD, 15));
		add(label, BorderLayout.PAGE_START);

		System.out.println("Current date: " + currentDate);

		// will put things
		created = new JLabel("");
		created.setFont(new Font("Serif", Font.BOLD, 15));
		add(created, BorderLayout.WEST); // pos
	}

	/**
	 * Returns the name of the account
	 * @return this.account
	 */
	public String getName() {
		return this.account;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		try {
			// when button clicked
			if (e.getSource() == button) {
				System.out.println("Click");
				for (int i = 0; i < model.getRowCount(); i++) {
					presence.add(model.getValueAt(i, 1).toString());
				} // get the selected combo box option

				System.out.println(presence);

				// classroom of account
				Classroom classroom = new Classroom(getName());

				// store presence inside file
				for (int st = 0; st < classroom.getStudents().size(); st++) {
					Student student = classroom.getStudents().get(st);
					classroom.updateAttendance(student, presence.get(st), currentDate);
				}

				button.setEnabled(false);
				JOptionPane.showConfirmDialog(null, "Attendance Set!", "Attendance",
						JOptionPane.OK_CANCEL_OPTION);

				MenuPage frame = new MenuPage("Menu Page", account);
				frame.getContentPane().setBackground(Color.LIGHT_GRAY);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.pack();
				frame.setSize(950, 500);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
				this.dispose();

			}
		}

		catch (NullPointerException err) {
			JOptionPane.showConfirmDialog(null, "Please Enter presence for all students", "Attendance",
					JOptionPane.WARNING_MESSAGE);
			System.out.println(err.getMessage());
		}

	}
}
