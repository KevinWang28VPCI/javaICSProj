import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * add column stating if person is student or teacher, display teachers first
 * then students
 * 
 * @author Kevin Wang, Piali Roy
 *
 */
public class StudentDisplay extends JFrame {
	private JTable table;
	private String account;
	private static String col[] = { "Name", "Grade", "ID", "Address", "       Presence     " }; // column headers
	private Object data[][] = {}; // no data for now
	private DefaultTableModel model;
	private Classroom classroom;
	private ArrayList<String> names = new ArrayList<String>();
	private ArrayList<String> id = new ArrayList<String>();
	private ArrayList<String> grade = new ArrayList<String>();
	private ArrayList<String> address = new ArrayList<String>();
	private ArrayList<Student> students = new ArrayList<Student>();
	private ArrayList<String> presence = new ArrayList<String>();

	private static final long serialVersionUID = 1;

	public StudentDisplay(String title, String account) {
		super(title);
		this.account = account;


		
		model = new DefaultTableModel(data, col); // table with size data and column
		table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		JScrollPane scrollPane = new JScrollPane(table); // make scrollable
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);


		classroom = new Classroom(account); // gets the specific classroom for the account
		System.out.println(classroom.getStudents());

		students = classroom.getStudents();
		
		for (int b = 0; b < classroom.getStudents().size(); b++) // half of array so no duplicates
		{
			names.add(students.get(b).getName()); // using getter methods for security
			grade.add(students.get(b).getGrade());
			id.add(students.get(b).getId());
			address.add(students.get(b).getAddress());
			presence.add(classroom.getPresence( (students.get(b)) .getName()));
		}

		// add rows to the JTable according to the amount of students there are
		for (int start = 0; start < id.size(); start++) {
			// Append a row
			model.addRow(new Object[] { names.get(start), grade.get(start), id.get(start), address.get(start), presence.get(start) }); // add info to rows
			// put this inside the loop for bufferedReader to easily create new columns
		}


		add(scrollPane); // add table to JFrame
		table.setEnabled(false); // not editable


	}
}